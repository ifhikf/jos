#!/bin/bash

while true
do
./wildrig-multi --print-full --algo mtp --opencl-threads auto --opencl-launch auto --url stratum+tcp://zcoin-eu.mintpond.com:3000 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
