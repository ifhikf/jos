#!/bin/bash

while true
do
./wildrig-multi --print-full --algo progpowz --url stratum+tcp://zano.luckypool.io:8877 --worker test --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
