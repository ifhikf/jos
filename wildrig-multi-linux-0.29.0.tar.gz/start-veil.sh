#!/bin/bash

while true
do
./wildrig-multi --print-full --algo progpow-veil --url pool.woolypooly.com:3098 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
