#!/bin/bash

while true
do
./wildrig-multi --print-full --algo progpow-sero --url stratum+tcp://sero-pool.beepool.org:9515 --worker test --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
