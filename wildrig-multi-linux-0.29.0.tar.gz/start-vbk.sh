#!/bin/bash

while true
do
./wildrig-multi --print-full --algo vprogpow --url stratum+tcp://veriblock.luckypool.io:9501 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
