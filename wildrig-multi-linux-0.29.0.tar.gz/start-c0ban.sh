#!/bin/bash

while true
do
./wildrig-multi --print-full --algo lyra2vc0ban --opencl-threads auto --opencl-launch auto --url stratum+tcp://eu.gos.cx:4650 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass c=RYO
sleep 5
done
