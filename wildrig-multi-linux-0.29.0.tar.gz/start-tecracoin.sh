#!/bin/bash

while true
do
./wildrig-multi --print-full --algo mtp-tcr --opencl-threads auto --opencl-launch auto --url stratum+tcp://pool-mtp.tecracoin.io:4556 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
