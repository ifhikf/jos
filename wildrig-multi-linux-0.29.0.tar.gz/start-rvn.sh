#!/bin/bash

while true
do
./wildrig-multi --print-full --algo kawpow --url stratum+tcp://pool.woolypooly.com:55555 --worker test --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
