#!/bin/bash

while true
do
./wildrig-multi --print-full --algo x25x --opencl-threads auto --opencl-launch auto --url stratum+tcp://eupool.sinovate.io:3253 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass c=SIN
sleep 5
done
