#!/bin/bash

while true
do
./wildrig-multi --print-full --algo megabtx --url stratum+tcp://stratum-eu.rplant.xyz:7066 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2--pass x
sleep 5
done
