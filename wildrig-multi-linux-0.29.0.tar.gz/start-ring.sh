#!/bin/bash

while true
do
./wildrig-multi --print-full --algo minotaur --url stratum+tcp://stratum-eu.rplant.xyz:7018 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2sleep 5
done
