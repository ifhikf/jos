#!/bin/bash

while true
do
./wildrig-multi --print-full --algo honeycomb --opencl-threads auto --opencl-launch auto --url stratum+tcp://pool.rplant.xyz:7018 --user RVWrWTyn5WCz1zqR15qm7bGeNcTZtmivs2.Donate --pass x
sleep 5
done
